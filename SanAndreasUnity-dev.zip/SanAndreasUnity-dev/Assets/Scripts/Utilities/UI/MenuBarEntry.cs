﻿using System.Collections.Generic;
using UnityEngine;

namespace SanAndreasUnity.Utilities
{

    public class MenuBarEntry : MonoBehaviour
    {
        public int sortPriority = 0;

    }

}
